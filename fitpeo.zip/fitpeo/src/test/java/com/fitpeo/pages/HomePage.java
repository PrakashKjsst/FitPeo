package com.fitpeo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.fitpeo.base.BaseClass;

public class HomePage extends BaseClass {
WebDriver driver;

	public HomePage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this );
	}
	
	@FindBy(xpath="//a/div[text()='Revenue Calculator']")
	private WebElement revenueCalculatorBtn ;
	
	public RevenueCalculatorPage openRevenueCalPage() {
		revenueCalculatorBtn.click();
		return new RevenueCalculatorPage(driver);
	}
	
}
