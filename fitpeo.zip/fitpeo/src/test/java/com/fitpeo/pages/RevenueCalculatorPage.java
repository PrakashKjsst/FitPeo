package com.fitpeo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.fitpeo.base.BaseClass;

public class RevenueCalculatorPage extends BaseClass {
WebDriver driver;

	public RevenueCalculatorPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this );
	}
	
	@FindBy(css ="input[type='range']")
	private WebElement slider ;
	
	@FindBy(css = ".MuiInputBase-root input")
	private WebElement sliderTxtField ;
	
	@FindBy(xpath = "//p[text()='Total Recurring Reimbursement for all Patients Per Month:']/p")
	private WebElement  totalRecurringReimbursement;
	
	public String getsliderTxtFiledValue() {
		return sliderTxtField.getAttribute("value");
	}
	
	public String getsliderRangeValue() {
		return slider.getAttribute("value");
	}
	
	public void setSliderRange() throws InterruptedException {
		waitTime();
		actionsClass().clickAndHold(slider).moveToLocation(907,0 ).release().perform();
		waitTime();
		scrollToElement(driver,sliderTxtField);
	}
	
	public void setSliderTxtFieldValue(String value) throws InterruptedException {
		scrollToElement(driver,sliderTxtField);
		waitTime();
		actionsClass().click(sliderTxtField).perform();
        sliderTxtField.sendKeys(Keys.CONTROL + "a"); 
        sliderTxtField.sendKeys(Keys.BACK_SPACE); 
        waitTime();
        actionsClass().sendKeys(sliderTxtField, value).perform();
	}
	
	public void selectCptCodes(String[] cptCodes) throws InterruptedException {
		for (String cptCode : cptCodes) {
			driver.findElement(By.xpath("//p[text()='"+cptCode+"']/parent::div/descendant::input")).click();
			waitTime();
		}  
	}
	
	public String getTotalRecurringReimbursement() {
		return totalRecurringReimbursement.getText();
	}
	
}
