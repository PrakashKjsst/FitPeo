package com.fitpeo.tests;

import org.testng.annotations.Test;

import com.fitpeo.base.BaseClass;
import com.fitpeo.pages.HomePage;
import com.fitpeo.pages.RevenueCalculatorPage;

import junit.framework.Assert;

public class FitpeoTest extends BaseClass{

	@Test
	public void fitPeoTasks() throws InterruptedException {
		//  Open the Fitpeo page
		HomePage homePage =setUp();
		waitTime();
		
		// Navigates to RevenueCalculator Page
		RevenueCalculatorPage revenueCalculatorPage = homePage.openRevenueCalPage();
		waitTime();
		
		// set & verify slider value 
		revenueCalculatorPage.setSliderRange();
		waitTime(); 
		Assert.assertEquals("823", revenueCalculatorPage.getsliderTxtFiledValue());
		
		// set & verify slider text field value
		String sliderValue = "560";
		revenueCalculatorPage.setSliderTxtFieldValue(sliderValue);
		waitTime();
		Assert.assertEquals(sliderValue, revenueCalculatorPage.getsliderRangeValue());
		
		revenueCalculatorPage.setSliderTxtFieldValue("820");

		
		// Check the CPT codes
		waitTime();
		String[]cptCodes = {"CPT-99091","CPT-99453","CPT-99454","CPT-99474"};
		revenueCalculatorPage.selectCptCodes(cptCodes);
		
		//Verify the Total Recurring Reimbursement Amount
		Assert.assertEquals("$110700", revenueCalculatorPage.getTotalRecurringReimbursement());

	}
}
