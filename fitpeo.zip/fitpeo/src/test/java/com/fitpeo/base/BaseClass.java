package com.fitpeo.base;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.fitpeo.pages.HomePage;

public class BaseClass {
	static WebDriver driver;
	@BeforeTest
	public HomePage setUp()
	{
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		driver.get("https://www.fitpeo.com/");
		return new HomePage(driver);
	}
	
	@AfterTest
	public void tearDown()
	{
		driver.quit();
	}
	
	public static void scrollToElement(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'})", element);
}

	public static Actions actionsClass() {
    	Actions actions = new Actions(driver);
    	return actions;
	}
	
	public static void waitTime() throws InterruptedException {
		Thread.sleep(3000);
	}
}
